E4.b
